from flask import Flask, render_template, redirect, url_for, request, flash
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from sqlalchemy import select, func, join, outerjoin
from collections import defaultdict
from datetime import date, datetime

# 2) Создаём приложение (обратите внимание на __name__)
app = Flask(__name__)
app.config['SECRET_KEY'] = 'change-me-to-random-secret'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///objects.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# 3) Привязываем SQLAlchemy к приложению
db.init_app(app)

# 4) Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'auth.login'


@login_manager.user_loader
def load_user(user_id):
    return Registered_Users.query.get(int(user_id))

# Регистрация blueprint'ов
from blueprints.auth import auth
from blueprints.main import main
from blueprints.objects_bp import objects_bp

app.register_blueprint(auth)
app.register_blueprint(main)
app.register_blueprint(objects_bp, url_prefix='/objects')

def can_edit(table_name):
    """Проверяет, имеет ли текущий пользователь право редактировать таблицу."""
    if not current_user.is_authenticated:
        return False
    role = current_user.role_id
    return role in EDIT_PERMISSIONS.get(table_name, [])

# ================== МАРШРУТЫ ==================

# ---------- ГЛАВНАЯ ----------
@app.route('/')
@login_required
def index():
    return render_template('index.html')


@app.route('/objects/<table_name>/delete/<int:item_id>', methods=['POST'])
@login_required
def delete_item(table_name, item_id):
    """Удаление строки — через маленькую форму с кнопкой."""
    if table_name not in TABLE_MAP:
        return "Таблица не найдена", 404
    if not can_edit(table_name):
        flash('У вас нет прав для удаления.', 'danger')
        return redirect(url_for('objects', table_name=table_name))

    model = TABLE_MAP[table_name]
    item = db.session.get(model, item_id)
    if item is None:
        flash('Запись не найдена.', 'warning')
    else:
        try:
            db.session.delete(item)
            db.session.commit()
            flash('Запись удалена.', 'success')
        except Exception as e:
            db.session.rollback()
            flash(f'Ошибка при удалении: {e}', 'danger')

    return redirect(url_for('objects', table_name=table_name))

# ================== СОЗДАНИЕ БД ==================
# ВАЖНО: этот блок выполняется при импорте модуля.
# Благодаря тому, что все модели импортированы СРАЗУ после from models import ...,
# они уже зарегистрированы в db.metadata к моменту вызова create_all().
with app.app_context():
    db.create_all()
    # В КОНЕЧНОМ ВАРИАНТЕ ЭТОЙ ЧАСТИ НЕ БУДЕТ. ОНА ЗДЕСЬ ВРЕМЕННО ДЛЯ ПРОВЕРКИ, КАК ВЫГЛЯДЯТ ТАБЛИЦЫ
    if User.query.count() == 0:
        db.session.add_all([
            User(full_name='admin', position='', role_id=1, email='',
                 phone='', user_login='admin',  is_registered=False),
        ])
        db.session.commit()


if __name__ == '__main__':
    app.run(debug=True)