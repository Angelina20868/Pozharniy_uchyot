from flask import Blueprint, render_template, redirect, url_for, request, flash
from sqlalchemy import select, func, outerjoin
from collections import defaultdict

from models import (
    db,
    Registered_Users,
    User,
    Divisions,
    UsersAtDivisions,
    Attestations,
    UsersAttestations,
    Vacations,
    Machines_Property,
    Technical_Maintenance,
    Forces_resources,
)

objects_bp = Blueprint('objects', __name__, url_prefix='/objects')

# Маппинг имён таблиц на модели
TABLE_MAP = {
    'user':                  User,
    'machines_property':     Machines_Property,
    'technical_maintenance': Technical_Maintenance,
    'attestations':          Attestations,
    'usersAttestations':     UsersAttestations,
    'divisions':             Divisions,
    'usersAtDivisions':      UsersAtDivisions,
    'vacations':             Vacations,
    'forces_resources':      Forces_resources,
}


# Какие role_id могут редактировать каждую таблицу
# 1 = админ, 2 = модератор, 3 = обычный пользователь
EDIT_PERMISSIONS = {
    'user':                  [1, 2],
    'machines_property':     [1, 2],
    'technical_maintenance': [1, 2],
    'attestations':          [1, 2],
    'usersAttestations':     [1, 2],
    'divisions':             [1],
    'usersAtDivisions':      [1],
    'vacations':             [1, 2, 3],
    'forces_resources':      [1, 2],
}


@objects_bp.route('/<table_name>')
def objects(table_name):
    if table_name not in TABLE_MAP:
        return "Таблица не найдена", 404
    
    model = TABLE_MAP[table_name]
    
    # ===== Специальная обработка: подразделения + сотрудники =====
    if table_name == 'usersAtDivisions':
        # ЗАПРОС 1: подсчёт сотрудников
        stmt_count = (
            select(
                Divisions.id,
                Divisions.div_name,
                func.count(User.id).label('user_count')
            )
            .outerjoin(UsersAtDivisions, UsersAtDivisions.div_id == Divisions.id)
            .outerjoin(User, User.id == UsersAtDivisions.user_id)
            .group_by(Divisions.id, Divisions.div_name)
            .order_by(Divisions.id)
        )
        stats = db.session.execute(stmt_count).all()
        
        # ЗАПРОС 2: список сотрудников
        stmt_rows = (
            select(Divisions, User)
            .outerjoin(UsersAtDivisions, UsersAtDivisions.div_id == Divisions.id)
            .outerjoin(User, User.id == UsersAtDivisions.user_id)
            .order_by(Divisions.id, User.full_name)
        )
        rows = db.session.execute(stmt_rows).all()
        
        # Группируем результат
        divisions_data = defaultdict(lambda: {
            'division': None,
            'users': [],
            'user_count': 0
        })
        
        for row in rows:
            div = row.Divisions
            user = row.User
            entry = divisions_data[div.id]
            entry['division'] = div
            if user is not None:
                entry['users'].append(user)
        
        for row in stats:
            divisions_data[row.id]['user_count'] = row.user_count
        
        return render_template('users_at_divisions.html',
                               divisions_data=divisions_data.values())
    
    # ===== Остальные таблицы =====
    stmt = select(model)
    items = db.session.execute(stmt).scalars().all()
    columns = [col.name for col in model.__table__.columns if col.name != 'id']
    
    return render_template('objects.html',
                           table_name=table_name,
                           items=items,
                           columns=columns)

def _coerce_value(column, raw_value):
    """Преобразует строку из формы в нужный Python-тип."""
    if raw_value == '' or raw_value is None:
        return None
    col_type = column.type
    if isinstance(col_type, db.Integer) or isinstance(col_type, db.SmallInteger):
        return int(raw_value)
    if isinstance(col_type, db.Float):
        return float(raw_value)
    if isinstance(col_type, db.Boolean):
        return raw_value.lower() in ('1', 'true', 'on', 'yes')
    if isinstance(col_type, db.Date):
        return datetime.strptime(raw_value, '%Y-%m-%d').date()
    return raw_value  # String, Text и т.д.

def _html_input_type(column):
    """Подбирает type для <input> на основе типа колонки."""
    col_type = column.type
    if isinstance(col_type, db.Date):
        return 'date'
    if isinstance(col_type, (db.Integer, db.SmallInteger)):
        return 'number'
    if isinstance(col_type, db.Float):
        return 'number'
    if isinstance(col_type, db.Boolean):
        return 'checkbox'
    return 'text'

@app.route('/objects.objects/<table_name>/delete/<int:item_id>', methods=['POST'])
@login_required
def delete_item(table_name, item_id):
    """Удаление строки — через маленькую форму с кнопкой."""
    if table_name not in TABLE_MAP:
        return "Таблица не найдена", 404
    if not can_edit(table_name):
        flash('У вас нет прав для удаления.', 'danger')
        return redirect(url_for('objects', table_name=table_name))

    model = TABLE_MAP[table_name]
    item = db.session.get(model, item_id)
    if item is None:
        flash('Запись не найдена.', 'warning')
    else:
        try:
            db.session.delete(item)
            db.session.commit()
            flash('Запись удалена.', 'success')
        except Exception as e:
            db.session.rollback()
            flash(f'Ошибка при удалении: {e}', 'danger')

    return redirect(url_for('objects', table_name=table_name))
